package tests;

import base.TestBase;
import config.TestConfig;
import org.openqa.selenium.Alert;
import org.openqa.selenium.UnhandledAlertException;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.LoginPage;

public class LoginTests extends TestBase {

    @Test
    public void testLoginWithData() {
        HomePage homePage = new HomePage(driver);
        LoginPage loginPage = new LoginPage(driver);

        try {
            homePage.openLoginModal();
            loginPage.fillLoginForm(
                    TestConfig.VALID_USERNAME,
                    TestConfig.VALID_PASSWORD
            );
            loginPage.submitLoginForm();

            // Handle potential alert
            try {
                Alert alert = driver.switchTo().alert();
                String alertText = alert.getText();
                alert.accept();
                Assert.fail("Login failed with alert: " + alertText);
            } catch (Exception e) {
                // No alert present, continue
            }

            // Wait for login to complete
            Thread.sleep(2000);

        } catch (UnhandledAlertException e) {
            // Handle unexpected alert
            Alert alert = driver.switchTo().alert();
            String alertText = alert.getText();
            alert.accept();
            Assert.fail("Unexpected alert during login: " + alertText);
        } catch (Exception e) {
            //Assert.fail("Test failed with exception: " + e.getMessage());
        }
    }

    @Test
    public void testLoginWithoutData() {
        HomePage homePage = new HomePage(driver);
        LoginPage loginPage = new LoginPage(driver);

        homePage.openLoginModal();
        loginPage.submitLoginForm();

        // Handle alert
        String alertText = driver.switchTo().alert().getText();
        driver.switchTo().alert().accept();

        //Assert.assertTrue(alertText.contains("Please fill out Username and Password"),
           //     "Empty login form submission didn't show validation error. Actual alert: " + alertText);
    }
}