package tests;

import base.TestBase;
import config.TestConfig;
import org.openqa.selenium.Alert;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.ContactPage;
import pages.HomePage;

public class ContactTests extends TestBase {

    @Test
    public void testContactFormWithData() {
        HomePage homePage = new HomePage(driver);
        ContactPage contactPage = new ContactPage(driver);

        homePage.openContactModal();
        contactPage.fillContactForm(
                TestConfig.VALID_EMAIL,
                TestConfig.VALID_NAME,
                TestConfig.VALID_MESSAGE
        );
        contactPage.submitContactForm();

        // Handle alert
        String alertText = "";
        try {
            Alert alert = driver.switchTo().alert();
            alertText = alert.getText();
            alert.accept();
        } catch (Exception e) {
           // Assert.fail("No alert present after form submission");
        }

       // Assert.assertTrue(alertText.contains("Thanks for the message"),
              //  "Contact form submission failed with valid data. Actual alert: " + alertText);
    }

    @Test
    public void testContactFormWithoutData() {
        HomePage homePage = new HomePage(driver);
        ContactPage contactPage = new ContactPage(driver);

        homePage.openContactModal();
        contactPage.submitContactForm();

        // Handle alert
        String alertText = "";
        try {
            Alert alert = driver.switchTo().alert();
            alertText = alert.getText();
            alert.accept();
        } catch (Exception e) {
          //  Assert.fail("No alert present for empty form submission");
        }


    }


}