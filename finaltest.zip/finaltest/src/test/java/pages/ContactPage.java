// src/test/java/pages/ContactPage.java
package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class ContactPage {
    private final WebDriver driver;

    @FindBy(id = "recipient-email")
    private WebElement emailField;

    @FindBy(id = "recipient-name")
    private WebElement nameField;

    @FindBy(id = "message-text")
    private WebElement messageField;

    @FindBy(xpath = "//button[contains(text(),'Send message')]")
    private WebElement sendMessageButton;

    public ContactPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void fillContactForm(String email, String name, String message) {
        new WebDriverWait(driver, Duration.ofSeconds(5))
                .until(ExpectedConditions.visibilityOf(emailField));

        emailField.clear();
        emailField.sendKeys(email);

        nameField.clear();
        nameField.sendKeys(name);

        messageField.clear();
        messageField.sendKeys(message);
    }

    public void submitContactForm() {
        sendMessageButton.click();
    }
}