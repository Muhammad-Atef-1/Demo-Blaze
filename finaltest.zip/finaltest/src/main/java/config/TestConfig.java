// src/main/java/config/TestConfig.java
package config;

public class TestConfig {
    public static final String BASE_URL = "https://www.demoblaze.com";
    public static final String VALID_EMAIL = "Aya@example.com";
    public static final String VALID_NAME = "Aya mkhemr";
    public static final String VALID_MESSAGE = "This is a test message";
    public static final String VALID_USERNAME = "valid_user";
    public static final String VALID_PASSWORD = "ValidPass123";
}