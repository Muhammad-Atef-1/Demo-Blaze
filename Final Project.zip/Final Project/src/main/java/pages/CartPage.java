package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.List;
import utilities.WaitHelper;

public class CartPage {
    WebDriver driver;
    WaitHelper waitHelper;

    private final By cartItemsLocator = By.cssSelector("#tbodyid tr"); // Locator for cart items
    private final By deleteButtonLocator = By.xpath("//a[text()='Delete']"); // Locator for delete button

    public void openCart() {
        driver.findElement(By.name("Cart")).click();
        waitHelper.waitForSeconds(2);
    }

    public List<Integer> getProductPrices() {
        List<WebElement> priceElements = driver.findElements(By.xpath("//tr/td[3]"));
        List<Integer> prices = new ArrayList<>();
        for (WebElement price : priceElements) {
            prices.add(Integer.parseInt(price.getText()));
        }
        return prices;
    }

   /* public int getTotalPrice() {
        WebElement totalEl = driver.findElement(By.id("totalp"));
        return Integer.parseInt(totalEl.getText());
    }*/

    public CartPage(WebDriver driver) {
        this.driver = driver;
        this.waitHelper = new WaitHelper(driver);
    }
    public void placeOrder(String name, String country, String city, String creditCard, String month, String year) {
        driver.findElement(By.xpath("//button[text()='Place Order']")).click();

        waitHelper.waitForElementToBeClickable(By.id("name"));
        driver.findElement(By.id("name")).sendKeys(name);
        driver.findElement(By.id("country")).sendKeys(country);
        driver.findElement(By.id("city")).sendKeys(city);
        driver.findElement(By.id("card")).sendKeys(creditCard);
        driver.findElement(By.id("month")).sendKeys(month);
        driver.findElement(By.id("year")).sendKeys(year);

        driver.findElement(By.xpath("//button[text()='Purchase']")).click();

        // Optional: print confirmation or close the confirmation modal
        WebElement confirmation = driver.findElement(By.cssSelector(".sweet-alert.showSweetAlert.visible"));
        System.out.println("Confirmation: " + confirmation.getText());
        driver.findElement(By.xpath("//button[text()='OK']")).click();
    }

    public void deleteAllItemsFromCart(boolean b) {
        List<WebElement> cartItems = driver.findElements(cartItemsLocator);

        while (!cartItems.isEmpty()) {
            WebElement firstDeleteButton = driver.findElement(deleteButtonLocator);
            waitHelper.waitForElementToBeClickable(firstDeleteButton);
            firstDeleteButton.click();

            // Wait for cart to update
            waitHelper.waitForSeconds(2);

            // Refresh cart items list
            cartItems = driver.findElements(cartItemsLocator);
        }
    }


    public int getCartItemCount() {
 return 0;
    }

}

