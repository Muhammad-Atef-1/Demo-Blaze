package pages;

import utilities.WaitHelper;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ProductPage {
    WebDriver driver;
    WaitHelper waitHelper;

    public ProductPage(WebDriver driver) {
        this.driver = driver;
        this.waitHelper = new WaitHelper(driver);
    }

    private By addToCartButton = By.xpath("//a[text()='Add to cart']");

    public void addToCart() {
        waitHelper.waitForElementToBeClickable(addToCartButton);
        driver.findElement(addToCartButton).click();
        waitHelper.waitForAlert();
        driver.switchTo().alert().accept(); // Accept the alert
        driver.navigate().back(); // Go back to homepage
    }
}
