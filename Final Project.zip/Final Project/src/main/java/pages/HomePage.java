package pages;

import org.openqa.selenium.WebElement;
import utilities.WaitHelper;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.List;

public class HomePage {
    WebDriver driver;
    public WaitHelper waitHelper;

    public HomePage(WebDriver driver) {
        this.driver = driver;
        this.waitHelper = new WaitHelper(driver);
    }
    public void navigateToHome() {
        driver.findElement(By.id("nav-link ")).click(); // Or use homepage logo/button
        waitHelper.waitForSeconds(2);
    }

    public void selectProduct(String productName) {
        By productLocator = By.xpath("//a[text()='" + productName + "']");

        List<WebElement> products = driver.findElements(productLocator);

        if (!products.isEmpty()) {
            waitHelper.waitForElementToBeClickable(productLocator);
            products.getFirst().click(); // Click the first found product
        } else {
            System.out.println("Product not found: " + productName);
        }
    }

}
