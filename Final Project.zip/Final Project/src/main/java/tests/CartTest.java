package tests;

import base.BaseTest;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import pages.CartPage;
import pages.HomePage;
import pages.ProductPage;
import org.openqa.selenium.By;



public class CartTest extends BaseTest {

    @Test
    public void testProductWorkflow() {
        HomePage homePage = new HomePage(driver);
        ProductPage productPage = new ProductPage(driver);
        CartPage cartPage = new CartPage(driver);

    }

    @Test
    public void addFiveItemsAndDeleteAscending() {
        HomePage homePage = new HomePage(driver);
        ProductPage productPage = new ProductPage(driver);
        CartPage cartPage = new CartPage(driver);

        homePage.selectProduct("Samsung galaxy s6");
        homePage.waitHelper.waitForSeconds(2);
        productPage.addToCart();
        homePage.waitHelper.waitForSeconds(2);
        driver.navigate().to("https://www.demoblaze.com");
        homePage.waitHelper.waitForSeconds(2);
        homePage.selectProduct("Nokia lumia 1520");
        homePage.waitHelper.waitForSeconds(2);
        productPage.addToCart();
        homePage.waitHelper.waitForSeconds(2);
        driver.navigate().to("https://www.demoblaze.com");
        homePage.waitHelper.waitForSeconds(2);
        homePage.selectProduct("Nexus 6");
        homePage.waitHelper.waitForSeconds(2);
        productPage.addToCart();
        homePage.waitHelper.waitForSeconds(2);
        driver.navigate().to("https://www.demoblaze.com");
        homePage.waitHelper.waitForSeconds(2);
        homePage.selectProduct("Sony xperia z5");
        homePage.waitHelper.waitForSeconds(2);
        productPage.addToCart();
        homePage.waitHelper.waitForSeconds(2);
        driver.navigate().to("https://www.demoblaze.com");
        homePage.waitHelper.waitForSeconds(2);
        driver.findElement(By.xpath("//*[@id=\"next2\"]")).click();
        homePage.waitHelper.waitForSeconds(2);
        homePage.selectProduct("MacBook air");
        homePage.waitHelper.waitForSeconds(2);
        productPage.addToCart();
        homePage.waitHelper.waitForSeconds(2);
        driver.navigate().to("https://www.demoblaze.com");
        homePage.waitHelper.waitForSeconds(2);
        driver.findElement(By.xpath("//*[@id=\"next2\"]")).click();
        homePage.waitHelper.waitForSeconds(2);
        homePage.selectProduct("MacBook Pro");
        homePage.waitHelper.waitForSeconds(2);
        productPage.addToCart();
        homePage.waitHelper.waitForSeconds(2);
        driver.navigate().to("https://www.demoblaze.com");
        homePage.waitHelper.waitForSeconds(2);
        driver.findElement(By.xpath("//*[@id=\"next2\"]")).click();
        homePage.waitHelper.waitForSeconds(2);
        homePage.selectProduct("ASUS Full HD");
        homePage.waitHelper.waitForSeconds(2);
        productPage.addToCart();
        homePage.waitHelper.waitForSeconds(2);
        driver.navigate().to("https://www.demoblaze.com");
        homePage.waitHelper.waitForSeconds(2);
        driver.findElement(By.xpath("//*[@id=\"next2\"]")).click();
        homePage.waitHelper.waitForSeconds(2);
        homePage.selectProduct("2017 Dell 15.6 Inch");
        homePage.waitHelper.waitForSeconds(2);
        productPage.addToCart();
        driver.findElement(By.id("cartur")).click(); // Go to cart
        //-----Purchase---😎
        homePage.waitHelper.waitForSeconds(2);
        cartPage.placeOrder("Eslam Elmhllawy", "Egypt", "Cairo", "01274340011", "04", "2025");
        homePage.waitHelper.waitForSeconds(2);
        driver.navigate().to("https://www.demoblaze.com");
        homePage.waitHelper.waitForSeconds(2);
       // driver.findElement(By.id("cartur")).click(); // Go to cart
        //homePage.waitHelper.waitForSeconds(2);
        homePage.selectProduct("Samsung galaxy s6");
        homePage.waitHelper.waitForSeconds(2);
        productPage.addToCart();
        driver.navigate().to("https://www.demoblaze.com");
        homePage.waitHelper.waitForSeconds(2);
        homePage.selectProduct("Nokia lumia 1520");
        homePage.waitHelper.waitForSeconds(2);
        productPage.addToCart();

        driver.findElement(By.id("cartur")).click(); // Go to cart

        cartPage.deleteAllItemsFromCart(true); // ascending
        assert cartPage.getCartItemCount() == 0;

       homePage.waitHelper.waitForSeconds(2);
          driver.navigate().to("https://www.demoblaze.com");
         homePage.waitHelper.waitForSeconds(2);

                driver.quit();
    }


}
